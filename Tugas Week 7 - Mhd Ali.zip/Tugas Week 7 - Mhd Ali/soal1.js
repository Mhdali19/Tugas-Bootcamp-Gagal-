// import dari file module.js kedalam variable rumus 
const rumus = require("./module.js"); 

// Menggunakan function kedalam masing masing variable 
const luasPersegiPanjang = rumus.luasPersegiPanjang(4, 6); 
const luasPersegi = rumus.luasPersegi(5);
const kelilingPersegi = rumus.kelilingPersegi(4);
const kelilingPersegiPanjang = rumus.kelilingPersegiPanjang(3, 4);

// Testingn function apakah berhasil 
console.log(luasPersegiPanjang); // 24
console.log(luasPersegi); // 25 
console.log(kelilingPersegi); // 16 
console.log(kelilingPersegiPanjang); // 14 