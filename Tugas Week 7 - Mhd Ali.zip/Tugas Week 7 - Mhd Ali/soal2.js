// import module fs 
const fs = require('fs');

// Baca terlebih dahulu data sample yang ada pada file datalog.txt
fs.readFile('datalog.txt', 'utf-8', (err, data) => {
    if(err) { // Periksa jika terjadi error
        console.errror('Gagal Baca File : ', err)
        return;
    }
    
    fs.writeFile('log.txt', data, (err) => { // Tulis data kembali pada file baru yang bernama log.txt
        if(err) { // Periksa kembali jika terjadi error
            console.error('Gagal Menulis data : ', err);
            return; 
        }
        console.log('Menulis ke dalam file baru berhasil') // Jika berhasil munculkan keterangan ini 
    })
})