// Buat function rumus 
function luasPersegi (sisi) {
    return sisi * sisi; 
}

function luasPersegiPanjang (panjang, lebar) {
    return panjang * lebar; 
}

function kelilingPersegi (sisi) {
    return 4 * sisi
}

function kelilingPersegiPanjang (panjang, lebar) {
    return 2 * (panjang + lebar); 
}

// Kirim function rumus
module.exports = {
    luasPersegi: luasPersegi,
    luasPersegiPanjang: luasPersegiPanjang, 
    kelilingPersegi: kelilingPersegi, 
    kelilingPersegiPanjang: kelilingPersegiPanjang
};

