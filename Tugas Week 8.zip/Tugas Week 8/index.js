const express = require('express');
const { Pool } = require('pg');

const app = express();

const pool = new Pool({
    user: 'postgres', 
    host: 'localhost', 
    database: 'dvdrental', 
    password: '12345678', 
    port: 5432, 
}); 

app.get('/data', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM film_list'); 
        res.json(result.rows); 
    } catch (err) {
        console.error('Error executing query', err); 
        res.status(500).send('Interval Server Error'); 
    }
}); 

const port = 3000; 
app.listen(port, () => {
    console.log(`Server berlaan di http://localhost:${port}`)
})


