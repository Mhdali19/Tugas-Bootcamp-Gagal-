
ALTER TABLE actor
ADD COLUMN age INT;

CREATE TABLE film (
    film_id SERIAL PRIMARY KEY,
    judul VARCHAR(255),
    tahun_rilis INT,
    durasi INT
);

CREATE TABLE category (
    category_id SERIAL PRIMARY KEY,
    nama_category VARCHAR(50)
);

CREATE TABLE film_category (
    film_id INT,
    category_id INT,
    FOREIGN KEY (film_id) REFERENCES film(film_id),
    FOREIGN KEY (category_id) REFERENCES category(category_id)
);

INSERT INTO film (judul, tahun_rilis, durasi) VALUES
('Film A', 2020, 120),
('Film B', 2018, 105),
('Film C', 2019, 130);

INSERT INTO category (nama_category) VALUES
('Action'),
('Comedy'),
('Drama');

INSERT INTO film_category (film_id, category_id) VALUES
(1, 1),
(2, 2),
(3, 3);
