const { Client } = require('pg');

const client = new Client({
  user: 'postgres',
  host: 'localhost',
  database: 'dvdrental',
  password: '12345678',
  port: 5432,
});


client.connect()
  .then(() => console.log('Connected to database'))
  .catch(err => console.error('Error connecting to database:', err.stack));


const query1 = "SELECT * FROM film";
client.query(query1)
  .then(res => {
    console.log('Data seluruh list film:');
    console.log(res.rows);
  })
  .catch(err => console.error('Error executing query:', err.stack));

const filmId = 1; 
const query2 = "SELECT * FROM film WHERE film_id = $1";
client.query(query2, [filmId])
  .then(res => {
    console.log('Data film dengan id ' + filmId + ':');
    console.log(res.rows);
  })
  .catch(err => console.error('Error executing query:', err.stack));


const query3 = "SELECT * FROM category";
client.query(query3)
  .then(res => {
    console.log('Data list category:');
    console.log(res.rows);
  })
  .catch(err => console.error('Error executing query:', err.stack));


const category = 'Action'; 
const query4 = `SELECT film.* 
                FROM film 
                JOIN film_category ON film.film_id = film_category.film_id 
                JOIN category ON film_category.category_id = category.category_id 
                WHERE category.nama_category = $1`;
client.query(query4, [category])
  .then(res => {
    console.log('Data list film dengan category ' + category + ':');
    console.log(res.rows);
  })
  .catch(err => console.error('Error executing query:', err.stack));


client.end();
